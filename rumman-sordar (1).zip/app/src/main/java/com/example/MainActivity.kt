package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.MicNone
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.MessengerConfirmDialog
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.VoiceScreen
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.PurpleNeon
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.RummanSordarTheme
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AssistantViewModel

enum class AppScreen {
    VOICE,
    CHAT,
    SETTINGS
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RummanSordarTheme {
                MainAppRoot()
            }
        }
    }
}

@Composable
fun MainAppRoot() {
    val context = LocalContext.current
    val viewModel: AssistantViewModel = viewModel()

    var currentScreen by remember { mutableStateOf(AppScreen.VOICE) }

    // Handle back button to return to Voice screen if on sub-screens
    BackHandler(enabled = currentScreen != AppScreen.VOICE) {
        currentScreen = AppScreen.VOICE
    }

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasMicPermission = isGranted
        if (isGranted) {
            viewModel.startListening()
        }
    }

    val isMessengerDialogOpen by viewModel.isMessengerDialogOpen.collectAsState()
    val pendingMessengerMessage by viewModel.pendingMessengerMessage.collectAsState()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                containerColor = DarkNavyCard,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                // Voice Tab
                NavigationBarItem(
                    selected = currentScreen == AppScreen.VOICE,
                    onClick = { currentScreen = AppScreen.VOICE },
                    icon = {
                        Icon(
                            imageVector = if (currentScreen == AppScreen.VOICE) Icons.Filled.Mic else Icons.Outlined.MicNone,
                            contentDescription = "ভয়েস"
                        )
                    },
                    label = { Text("ভয়েস", fontSize = 12.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = PurpleNeon,
                        indicatorColor = PurplePrimary,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("nav_voice_tab")
                )

                // Chat Tab
                NavigationBarItem(
                    selected = currentScreen == AppScreen.CHAT,
                    onClick = { currentScreen = AppScreen.CHAT },
                    icon = {
                        Icon(
                            imageVector = if (currentScreen == AppScreen.CHAT) Icons.Filled.ChatBubble else Icons.Outlined.ChatBubbleOutline,
                            contentDescription = "চ্যাট"
                        )
                    },
                    label = { Text("চ্যাট", fontSize = 12.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = PurpleNeon,
                        indicatorColor = PurplePrimary,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("nav_chat_tab")
                )

                // Settings Tab
                NavigationBarItem(
                    selected = currentScreen == AppScreen.SETTINGS,
                    onClick = { currentScreen = AppScreen.SETTINGS },
                    icon = {
                        Icon(
                            imageVector = if (currentScreen == AppScreen.SETTINGS) Icons.Filled.Settings else Icons.Outlined.Settings,
                            contentDescription = "সেটিংস"
                        )
                    },
                    label = { Text("সেটিংস", fontSize = 12.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = PurpleNeon,
                        indicatorColor = PurplePrimary,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("nav_settings_tab")
                )
            }
        }
    ) { innerPadding ->
        when (currentScreen) {
            AppScreen.VOICE -> VoiceScreen(
                viewModel = viewModel,
                hasMicPermission = hasMicPermission,
                onRequestPermission = {
                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                },
                modifier = Modifier.padding(innerPadding)
            )

            AppScreen.CHAT -> ChatScreen(
                viewModel = viewModel,
                hasMicPermission = hasMicPermission,
                onRequestPermission = {
                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                },
                modifier = Modifier.padding(innerPadding)
            )

            AppScreen.SETTINGS -> SettingsScreen(
                viewModel = viewModel,
                hasMicPermission = hasMicPermission,
                onRequestPermission = {
                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                },
                modifier = Modifier.padding(innerPadding)
            )
        }

        // Messenger confirmation dialog
        MessengerConfirmDialog(
            isOpen = isMessengerDialogOpen,
            messageText = pendingMessengerMessage,
            onConfirm = { viewModel.confirmSendMessenger(context) },
            onDismiss = { viewModel.dismissMessengerDialog() }
        )
    }
}
