package com.example.data.ai

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class AiAssistantService {

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    /**
     * Checks if a valid non-placeholder Gemini API key is configured.
     */
    fun isGeminiConfigured(): Boolean {
        val key = BuildConfig.GEMINI_API_KEY
        return !key.isNullOrBlank() && key != "MY_GEMINI_API_KEY" && !key.startsWith("YOUR_")
    }

    suspend fun getResponse(userMessage: String): String = withContext(Dispatchers.IO) {
        val trimmed = userMessage.trim()
        if (trimmed.isEmpty()) {
            return@withContext "দয়া করে কিছু বলুন, আমি শুনছি।"
        }

        // Try Gemini API if configured
        if (isGeminiConfigured()) {
            try {
                val geminiReply = callGeminiApi(trimmed)
                if (geminiReply.isNotBlank()) {
                    return@withContext geminiReply
                }
            } catch (e: Exception) {
                e.printStackTrace()
                // Fall back to intelligent local Bengali engine
            }
        }

        // Offline / zero-config smart Bengali conversation engine
        generateSmartBengaliResponse(trimmed)
    }

    private fun callGeminiApi(userMessage: String): String {
        val apiKey = BuildConfig.GEMINI_API_KEY
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$apiKey"

        val systemPrompt = "You are Rumman Sordar's AI voice assistant (রুমান সরদার এআই). You are a friendly, warm, empathetic female AI assistant speaking fluent, natural, polite Bengali (বাংলা). Keep voice conversation responses concise (usually 1-3 sentences) so they sound natural and engaging when spoken aloud. Be helpful, enthusiastic, and respectful."

        val requestJson = JSONObject().apply {
            val systemInstructionObj = JSONObject().apply {
                val partsArray = JSONArray().apply {
                    put(JSONObject().put("text", systemPrompt))
                }
                put("parts", partsArray)
            }
            put("systemInstruction", systemInstructionObj)

            val contentsArray = JSONArray().apply {
                val contentObj = JSONObject().apply {
                    put("role", "user")
                    val parts = JSONArray().apply {
                        put(JSONObject().put("text", userMessage))
                    }
                    put("parts", parts)
                }
                put(contentObj)
            }
            put("contents", contentsArray)

            val genConfig = JSONObject().apply {
                put("temperature", 0.7)
                put("maxOutputTokens", 400)
            }
            put("generationConfig", genConfig)
        }

        val requestBody = requestJson.toString().toRequestBody(jsonMediaType)
        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        val response = httpClient.newCall(request).execute()
        val responseBody = response.body?.string() ?: ""

        if (!response.isSuccessful) {
            throw RuntimeException("Gemini API error ${response.code}: $responseBody")
        }

        val rootObj = JSONObject(responseBody)
        val candidates = rootObj.optJSONArray("candidates")
        if (candidates != null && candidates.length() > 0) {
            val candidate = candidates.getJSONObject(0)
            val content = candidate.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            if (parts != null && parts.length() > 0) {
                return parts.getJSONObject(0).optString("text", "").trim()
            }
        }

        return ""
    }

    private fun generateSmartBengaliResponse(query: String): String {
        val lower = query.lowercase()

        // 1. Messenger & message preparation
        if (lower.contains("মেসেঞ্জার") || lower.contains("messenger") || lower.contains("মেসেজ পাঠা") || lower.contains("বার্তা পাঠা")) {
            return "আমি আপনার জন্য মেসেঞ্জারে বার্তা প্রস্তুত করেছি! নিচে মেসেঞ্জার বাটনে ট্যাপ করে বার্তাটি নিশ্চিত করুন এবং সরাসরি মেসেঞ্জারে পাঠান।"
        }

        // 2. Greetings
        if (lower.contains("কেমন আছ") || lower.contains("how are you")) {
            return "আমি বেশ ভালো আছি, ধন্যবাদ! আপনার আজকের দিনটি কেমন যাচ্ছে?"
        }
        if (lower.contains("হ্যালো") || lower.contains("hello") || lower.contains("হাই") || lower.contains("hi") || lower.contains("সালাম") || lower.contains("নমস্কার")) {
            return "হ্যালো! আসসালামু আলাইকুম। আমি আপনার রুমান সরদার এআই সহকারী। বলুন, আজ আপনাকে কীভাবে সাহায্য করতে পারি?"
        }
        if (lower.contains("নাম কী") || lower.contains("তোমার নাম") || lower.contains("কে তুমি") || lower.contains("who are you")) {
            return "আমার নাম রুমান সরদার এআই (Rumman Sordar AI)। আমি আপনার মিষ্টি এবং বুদ্ধিমান বাংলা ভয়েস সহকারী।"
        }

        // 3. Jokes / Koutuk
        if (lower.contains("কৌতুক") || lower.contains("হাস্যরস") || lower.contains("মজা") || lower.contains("joke")) {
            val jokes = listOf(
                "শুনুন তবে একটি মজার কৌতুক! ডাক্তার বললেন রোগীকে: আপনার তো ওজন আগের চেয়ে বেড়েছে, কী খাচ্ছেন? রোগী বললেন: শুধু আপনার প্রেসক্রিপশন বাদে বাকি সবকিছু!",
                "শিক্ষক ছাত্রকে জিজ্ঞেস করলেন: পৃথিবীর সবচেয়ে প্রাচীন প্রাণী কোনটি? ছাত্র হাসিমুখে উত্তর দিল: জেব্রা স্যার! কারণ সে এখনও সাদা-কালো যুগে বাস করছে!",
                "বাবা খোকাকে বললেন: পরীক্ষায় শূন্য পেলে আমি কী করবো জানো? খোকা বলল: জানি বাবা, ডিম ভেজে আমাকে খাওয়াবে!"
            )
            return jokes.random()
        }

        // 4. Poetry & Song
        if (lower.contains("কবিতা") || lower.contains("গান") || lower.contains("poem") || lower.contains("song")) {
            val poems = listOf(
                "রবীন্দ্রনাথ ঠাকুরের একটি সুন্দর কবিতা মনে পড়ে গেল—\n'আমাদের ছোট নদী চলে বাঁকে বাঁকে,\nবৈশাখ মাসে তার হাঁটু জল থাকে।\nপার হয়ে যায় গরু, পার হয় গাড়ি,\nদুই ধার উঁচু তার, ঢালু তার পাড়ি।'",
                "কাজী নজরুল ইসলামের অমর গান—\n'মোরা একই বৃন্তে দুটি কুসুম হিন্দু-মুসলমান,\nমুসলিম তার নয়ন-মণি, হিন্দু তাহার প্রাণ।'",
                "জীবনানন্দ দাশের বিখ্যাত পঙ্‌ক্তি—\n'হাজার বছর ধরে আমি পথ হাঁটিতেছি পৃথিবীর পথে,\nসিংহল সমুদ্র থেকে নিশীথের অন্ধকারে মালয় সাগরে...'"
            )
            return poems.random()
        }

        // 5. Time & Date
        if (lower.contains("সময়") || lower.contains("কয়টা বাজে") || lower.contains("time") || lower.contains("তারিখ") || lower.contains("date")) {
            val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
            val bnLocale = Locale.Builder().setLanguage("bn").setRegion("BD").build()
            val dateFormat = SimpleDateFormat("dd MMMM, yyyy", bnLocale)
            val currentTime = timeFormat.format(Date())
            val currentDate = dateFormat.format(Date())
            return "এখন স্থানীয় সময় আনুমানিক $currentTime এবং তারিখ $currentDate।"
        }

        // 6. Good morning / night
        if (lower.contains("শুভ সকাল") || lower.contains("good morning")) {
            return "শুভ সকাল! একটি নতুন সকাল আপনার জন্য আনন্দ ও সাফল্য বয়ে নিয়ে আসুক।"
        }
        if (lower.contains("শুভ রাত্রি") || lower.contains("good night")) {
            return "শুভ রাত্রি! মিষ্টি ঘুমে শান্তিময় বিশ্রাম নিন। কাল আবার কথা হবে।"
        }

        // 7. Bengali language praise
        if (lower.contains("বাংলা") || lower.contains("ভাষা")) {
            return "বাংলা আমাদের মায়ের ভাষা, বিশ্বের অন্যতম মিষ্টি এবং শ্রুতিমধুর ভাষা। আপনার সাথে বাংলায় কথা বলতে পেরে আমার খুব ভালো লাগছে!"
        }

        // 8. Help & Guidance
        if (lower.contains("সাহায্য") || lower.contains("help") || lower.contains("কী করতে পার")) {
            return "আমি আপনার সাথে মিষ্টি বাংলায় বাস্তব সময়ে কথা বলতে পারি, প্রশ্নের উত্তর দিতে পারি, গল্প বা কৌতুক শোনাতে পারি এবং মেসেঞ্জারের জন্য সুন্দর বার্তা তৈরি করে দিতে পারি।"
        }

        // 9. Compliment
        if (lower.contains("ধন্যবাদ") || lower.contains("thanks") || lower.contains("থ্যাংক")) {
            return "আপনাকেও অসংখ্য ধন্যবাদ! আপনার সাথে কথা বলতে পেরে আমি আনন্দিত। আর কোনো সাহায্য লাগবে কি?"
        }
        if (lower.contains("সুন্দর") || lower.contains("ভাল") || lower.contains("ভালো") || lower.contains("মিষ্টি")) {
            return "অনেক ধন্যবাদ আপনার মিষ্টি প্রশংসার জন্য! আপনিও অনেক অমায়িক।"
        }

        // Default conversational response in polite Bengali
        return "আপনার কথাটি আমি গভীর মনোযোগ দিয়ে শুনলাম: \"$query\"। আমি আপনার পাশে সবসময় আছি, আপনি চাইলে আরও প্রশ্ন করতে পারেন অথবা যেকোনো বিষয় নিয়ে আমার সাথে কথা বলতে পারেন।"
    }
}
