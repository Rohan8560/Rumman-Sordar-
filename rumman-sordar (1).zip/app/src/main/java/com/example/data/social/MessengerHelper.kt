package com.example.data.social

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.widget.Toast

object MessengerHelper {
    private const val MESSENGER_PACKAGE = "com.facebook.orca"

    fun isMessengerInstalled(context: Context): Boolean {
        return try {
            val pm = context.packageManager
            pm.getPackageInfo(MESSENGER_PACKAGE, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Opens Facebook Messenger with the prepared message text if installed,
     * or opens the system share chooser with Messenger/messages option.
     */
    fun openMessengerWithMessage(context: Context, messageText: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, messageText)
            }

            if (isMessengerInstalled(context)) {
                intent.setPackage(MESSENGER_PACKAGE)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                true
            } else {
                // Fallback to chooser so user can send via Messenger Lite, WhatsApp, or SMS
                val chooser = Intent.createChooser(intent, "মেসেঞ্জারে বা অন্য অ্যাপে পাঠান")
                chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(chooser)
                Toast.makeText(
                    context,
                    "মেসেঞ্জার অ্যাপ সরাসরি পাওয়া যায়নি, শেয়ার মেনু খোলা হচ্ছে",
                    Toast.LENGTH_SHORT
                ).show()
                true
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "মেসেঞ্জার খুলতে সমস্যা হয়েছে: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            false
        }
    }
}
