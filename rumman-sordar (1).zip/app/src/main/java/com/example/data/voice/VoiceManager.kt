package com.example.data.voice

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import java.util.Locale

class VoiceManager(
    private val context: Context,
    private val onTranscriptUpdate: (String, Boolean) -> Unit, // text, isFinal
    private val onRmsChanged: (Float) -> Unit,
    private val onSpeechStateChanged: (Boolean) -> Unit, // isSpeaking
    private val onError: (String) -> Unit
) : TextToSpeech.OnInitListener {

    companion object {
        private const val TAG = "VoiceManager"
        const val GOOGLE_TTS_ENGINE = "com.google.android.tts"
    }

    private var tts: TextToSpeech? = null
    var isTtsReady: Boolean = false
        private set

    var activeEngineName: String = "Initializing..."
        private set

    var activeVoiceName: String = "Detecting voice..."
        private set

    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false

    var currentPitch: Float = 1.22f // Calibrated for a sweet, natural, friendly female tone
        set(value) {
            field = value
            tts?.setPitch(value)
        }

    var currentRate: Float = 0.94f // Natural, conversational cadence
        set(value) {
            field = value
            tts?.setSpeechRate(value)
        }

    var selectedLocaleTag: String = "bn-BD" // "bn-BD" or "bn-IN"
        set(value) {
            field = value
            if (isTtsReady) {
                applyBestBengaliVoice()
            }
        }

    init {
        initTts()
        initSpeechRecognizer()
    }

    private fun initTts() {
        // Attempt to initialize using Google TTS engine first for premium neural/wavenet Bengali synthesis
        try {
            tts = TextToSpeech(context.applicationContext, this, GOOGLE_TTS_ENGINE)
            activeEngineName = "Google Speech Services"
        } catch (e: Exception) {
            Log.w(TAG, "Failed to initialize Google TTS, falling back to default engine: ${e.message}")
            tts = TextToSpeech(context.applicationContext, this)
            activeEngineName = "System Default Engine"
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            configureAudioAttributes()
            applyBestBengaliVoice()
            setupUtteranceListener()
            isTtsReady = true
            Log.d(TAG, "TTS initialized successfully with engine: $activeEngineName, voice: $activeVoiceName")
        } else {
            // If Google TTS engine failed to init, retry with standard constructor
            if (activeEngineName == "Google Speech Services") {
                Log.w(TAG, "Google TTS failed with code $status, retrying with system default engine")
                activeEngineName = "System Default Engine"
                tts = TextToSpeech(context.applicationContext, this)
            } else {
                Log.e(TAG, "TTS initialization failed completely with code $status")
                activeVoiceName = "TTS Error"
                onError("ভয়েস ইঞ্জিন প্রস্তুত হতে পারেনি।")
            }
        }
    }

    private fun configureAudioAttributes() {
        try {
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            tts?.setAudioAttributes(audioAttributes)
        } catch (e: Exception) {
            Log.w(TAG, "Could not set audio attributes: ${e.message}")
        }
    }

    /**
     * Finds and applies the highest quality, most natural Bengali female voice available.
     */
    fun applyBestBengaliVoice() {
        val targetLocale = if (selectedLocaleTag == "bn-IN") {
            Locale.Builder().setLanguage("bn").setRegion("IN").build()
        } else {
            Locale.Builder().setLanguage("bn").setRegion("BD").build()
        }

        // 1. Set language on engine
        var langResult = tts?.setLanguage(targetLocale)
        if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
            // Fallback to general Bengali
            val genericBn = Locale.Builder().setLanguage("bn").build()
            langResult = tts?.setLanguage(genericBn)
            if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.w(TAG, "Bengali language not directly supported by engine, using system default")
                tts?.setLanguage(Locale.getDefault())
            }
        }

        // 2. Scan available voices for natural female Bengali profiles
        try {
            val allVoices = tts?.voices
            if (!allVoices.isNullOrEmpty()) {
                val bengaliVoices = allVoices.filter { voice ->
                    voice.locale.language.equals("bn", ignoreCase = true)
                }

                if (bengaliVoices.isNotEmpty()) {
                    // Score and pick the best natural female voice
                    val bestVoice = bengaliVoices.maxByOrNull { voice ->
                        var score = 0
                        val name = voice.name.lowercase()

                        // High preference for female identifiers
                        if (name.contains("female") || name.contains("fem") || name.contains("f0") || name.contains("f_") || name.contains("bif")) {
                            score += 50
                        }

                        // High preference for neural / network / wavenet / natural
                        if (name.contains("network") || name.contains("neural") || name.contains("natural") || name.contains("wavenet")) {
                            score += 30
                        }

                        // Preferred regional locale match
                        if (voice.locale.country.equals(targetLocale.country, ignoreCase = true)) {
                            score += 20
                        }

                        // Quality metric if provided
                        if (voice.quality >= Voice.QUALITY_VERY_HIGH) {
                            score += 15
                        } else if (voice.quality >= Voice.QUALITY_HIGH) {
                            score += 10
                        }

                        score
                    }

                    if (bestVoice != null) {
                        tts?.voice = bestVoice
                        activeVoiceName = formatVoiceDisplayName(bestVoice.name)
                        Log.i(TAG, "Selected natural Bengali voice: ${bestVoice.name}")
                    } else {
                        activeVoiceName = "Bengali (${targetLocale.displayCountry})"
                    }
                } else {
                    activeVoiceName = "Standard Bengali"
                }
            } else {
                activeVoiceName = "Default Bengali"
            }
        } catch (e: Exception) {
            Log.w(TAG, "Voice enumeration failed: ${e.message}")
            activeVoiceName = "Bengali Voice"
        }

        // 3. Set natural pitch and speed modulation
        tts?.setPitch(currentPitch)
        tts?.setSpeechRate(currentRate)
    }

    private fun formatVoiceDisplayName(rawName: String): String {
        return when {
            rawName.contains("bn-bd-x-ban-network", ignoreCase = true) -> "Google Bengali BD (Neural Female)"
            rawName.contains("bn-bd-x-ban-local", ignoreCase = true) -> "Bengali BD (Local Natural)"
            rawName.contains("bn-in-x-bif", ignoreCase = true) -> "Google Bengali IN (Sweet Female)"
            rawName.contains("bn-in-x-bin", ignoreCase = true) -> "Google Bengali IN (Natural)"
            rawName.contains("female", ignoreCase = true) -> "Bengali Female (${rawName.take(16)})"
            else -> rawName.replace("_", " ").take(24)
        }
    }

    private fun setupUtteranceListener() {
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                onSpeechStateChanged(true)
            }

            override fun onDone(utteranceId: String?) {
                onSpeechStateChanged(false)
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                onSpeechStateChanged(false)
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                onSpeechStateChanged(false)
                Log.w(TAG, "TTS Utterance error code: $errorCode")
            }
        })
    }

    private fun initSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}

                    override fun onBeginningOfSpeech() {}

                    override fun onRmsChanged(rmsdB: Float) {
                        val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                        this@VoiceManager.onRmsChanged(normalized)
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        isListening = false
                    }

                    override fun onError(error: Int) {
                        isListening = false
                        this@VoiceManager.onRmsChanged(0f)
                        val message = when (error) {
                            SpeechRecognizer.ERROR_NO_MATCH -> "কথা স্পষ্ট শোনা যায়নি। দয়া করে আবার বলুন।"
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "কোন কথা শোনা যায়নি।"
                            SpeechRecognizer.ERROR_AUDIO -> "মাইক্রোফোনে সমস্যা হয়েছে।"
                            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "ইন্টারনেট সংযোগে সমস্যা হয়েছে।"
                            else -> "ভয়েস রিকগনিশনে সমস্যা হয়েছে।"
                        }
                        this@VoiceManager.onError(message)
                    }

                    override fun onResults(results: Bundle?) {
                        isListening = false
                        this@VoiceManager.onRmsChanged(0f)
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (!matches.isNullOrEmpty()) {
                            val recognizedText = matches[0]
                            onTranscriptUpdate(recognizedText, true)
                        } else {
                            this@VoiceManager.onError("কোন কথা শোনা যায়নি।")
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (!matches.isNullOrEmpty()) {
                            val partialText = matches[0]
                            onTranscriptUpdate(partialText, false)
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        }
    }

    fun startListening() {
        if (speechRecognizer == null) {
            initSpeechRecognizer()
        }

        stopSpeaking()

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (selectedLocaleTag == "bn-IN") "bn-IN" else "bn-BD")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, if (selectedLocaleTag == "bn-IN") "bn-IN" else "bn-BD")
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }

        try {
            isListening = true
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            isListening = false
            onError("মাইক্রোফোন চালু করতে সমস্যা: ${e.localizedMessage}")
        }
    }

    fun stopListening() {
        if (isListening) {
            isListening = false
            try {
                speechRecognizer?.stopListening()
            } catch (e: Exception) {
                // Ignore
            }
        }
    }

    /**
     * Cleans and prepares Bengali text for natural, conversational speech delivery.
     * Removes markdown formatting, asterisks, bullet points and ensures natural pauses.
     */
    private fun cleanTextForSpeech(rawText: String): String {
        return rawText
            // Remove markdown bold/italics
            .replace(Regex("\\*\\*|\\*|_|#+"), "")
            // Remove code block markers
            .replace(Regex("`+"), "")
            // Replace emojis and special symbols with natural pause
            .replace(Regex("[\\p{So}\\p{Cn}]"), " ")
            // Ensure space after Bengali full stop (dari) and commas for breath pauses
            .replace("।", "। ")
            .replace(",", ", ")
            // Clean up multi-spaces
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun speak(text: String, utteranceId: String = System.currentTimeMillis().toString()) {
        if (!isTtsReady || tts == null) {
            Log.w(TAG, "TTS is not ready yet, attempting re-init")
            initTts()
            return
        }

        val speechText = cleanTextForSpeech(text)
        if (speechText.isBlank()) return

        tts?.setPitch(currentPitch)
        tts?.setSpeechRate(currentRate)

        val params = Bundle().apply {
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
        }
        tts?.speak(speechText, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
    }

    fun stopSpeaking() {
        try {
            if (tts?.isSpeaking == true) {
                tts?.stop()
                onSpeechStateChanged(false)
            }
        } catch (e: Exception) {
            // Ignore
        }
    }

    fun release() {
        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
            tts?.stop()
            tts?.shutdown()
            tts = null
        } catch (e: Exception) {
            // Ignore
        }
    }
}
