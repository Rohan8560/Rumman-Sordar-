package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.PinkAccent
import com.example.ui.theme.PurpleNeon
import com.example.ui.theme.PurplePrimary
import kotlin.math.sin

@Composable
fun AudioVisualizer(
    isActive: Boolean,
    audioLevel: Float,
    isSpeaking: Boolean,
    modifier: Modifier = Modifier,
    height: Dp = 48.dp,
    barCount: Int = 24
) {
    val transition = rememberInfiniteTransition(label = "viz_anim")
    val waveOffset by transition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_phase"
    )

    val gradientColors = if (isSpeaking) {
        listOf(PurpleNeon, PinkAccent, PurplePrimary)
    } else if (isActive) {
        listOf(CyanNeon, CyanAccent, PurpleNeon)
    } else {
        listOf(PurplePrimary.copy(alpha = 0.3f), CyanNeon.copy(alpha = 0.3f))
    }

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
    ) {
        val totalWidth = size.width
        val canvasHeight = size.height
        val barWidth = (totalWidth / (barCount * 1.6f)).coerceIn(3f, 10f)
        val spacing = (totalWidth - (barWidth * barCount)) / (barCount + 1)

        val centerY = canvasHeight / 2f

        for (i in 0 until barCount) {
            val x = spacing + i * (barWidth + spacing)

            val baseHeightFactor = if (isActive || isSpeaking) {
                // Sine wave variation modulated by bar position and audioLevel
                val wave = (sin(waveOffset + (i * 0.45f)) + 1f) / 2f
                val dynamicLevel = if (isSpeaking) 0.5f + (wave * 0.5f) else (audioLevel * 0.7f + wave * 0.3f)
                dynamicLevel.coerceIn(0.15f, 1f)
            } else {
                0.08f
            }

            val barHeight = (canvasHeight * baseHeightFactor).coerceAtLeast(4f)
            val topY = centerY - (barHeight / 2f)

            drawRoundRect(
                brush = Brush.verticalGradient(
                    colors = gradientColors,
                    startY = topY,
                    endY = topY + barHeight
                ),
                topLeft = Offset(x, topY),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
            )
        }
    }
}
