package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.SpeechState
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.DarkNavyBackground
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.PinkAccent
import com.example.ui.theme.PurpleGlow
import com.example.ui.theme.PurpleNeon
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.StatusReady

@Composable
fun AvatarView(
    speechState: SpeechState,
    isSpeaking: Boolean,
    audioLevel: Float,
    modifier: Modifier = Modifier,
    size: Dp = 220.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "avatar_anim")

    // Ambient breathing scale
    val breathScale by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breath_scale"
    )

    // Pulse glow animation for speaking and listening
    val pulseGlow by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_glow"
    )

    // Mouth animation cycle while speaking (natural talking rhythm)
    val mouthCycle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(220, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "mouth_cycle"
    )

    val activeGlowColor = when {
        isSpeaking -> PurpleNeon
        speechState == SpeechState.LISTENING -> CyanNeon
        speechState == SpeechState.THINKING -> PinkAccent
        else -> PurplePrimary.copy(alpha = 0.5f)
    }

    Box(
        modifier = modifier
            .size(size + 60.dp)
            .testTag("avatar_container"),
        contentAlignment = Alignment.Center
    ) {
        // Outer glowing energy rings
        Canvas(modifier = Modifier.size(size + 50.dp)) {
            val center = Offset(this.size.width / 2, this.size.height / 2)
            val baseRadius = size.toPx() / 2

            if (isSpeaking || speechState == SpeechState.LISTENING) {
                // Outer expanding ripple
                val rippleRadius = baseRadius + (pulseGlow * 30.dp.toPx())
                val alpha = (1f - pulseGlow) * 0.7f
                drawCircle(
                    color = activeGlowColor.copy(alpha = alpha),
                    radius = rippleRadius,
                    center = center,
                    style = Stroke(width = 3.dp.toPx())
                )
                // Second subtle ring
                val rippleRadius2 = baseRadius + (((pulseGlow + 0.5f) % 1f) * 30.dp.toPx())
                val alpha2 = (1f - ((pulseGlow + 0.5f) % 1f)) * 0.4f
                drawCircle(
                    color = CyanAccent.copy(alpha = alpha2),
                    radius = rippleRadius2,
                    center = center,
                    style = Stroke(width = 2.dp.toPx())
                )
            } else {
                // Gentle idle halo
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            PurplePrimary.copy(alpha = 0.35f),
                            Color.Transparent
                        ),
                        center = center,
                        radius = baseRadius + 20.dp.toPx()
                    ),
                    radius = baseRadius + 20.dp.toPx(),
                    center = center
                )
            }
        }

        // Avatar Image Container with breathing scale
        Box(
            modifier = Modifier
                .size(size)
                .scale(if (isSpeaking || speechState == SpeechState.LISTENING) breathScale * 1.02f else breathScale)
                .shadow(
                    elevation = if (isSpeaking) 24.dp else 12.dp,
                    shape = CircleShape,
                    ambientColor = activeGlowColor,
                    spotColor = activeGlowColor
                )
                .border(
                    width = 3.5.dp,
                    brush = Brush.sweepGradient(
                        listOf(
                            PurpleNeon,
                            CyanNeon,
                            PurplePrimary,
                            PinkAccent,
                            PurpleNeon
                        )
                    ),
                    shape = CircleShape
                )
                .clip(CircleShape)
                .background(DarkNavyCard)
        ) {
            // Friendly 3D female avatar image
            Image(
                painter = painterResource(id = R.drawable.img_avatar_friendly),
                contentDescription = "Friendly Bengali Female AI Avatar",
                modifier = Modifier
                    .size(size)
                    .testTag("avatar_image"),
                contentScale = ContentScale.Crop
            )

            // Animated Mouth Overlay while speaking
            if (isSpeaking) {
                Canvas(
                    modifier = Modifier
                        .size(size)
                        .testTag("avatar_animated_mouth")
                ) {
                    val w = this.size.width
                    val h = this.size.height

                    // The mouth is located approximately at 63% from top, centered horizontally
                    val mouthCenterX = w * 0.495f
                    val mouthCenterY = h * 0.628f

                    // Talking open ratio oscillates between 0.2f and 1.0f based on mouthCycle
                    val openFactor = 0.25f + (mouthCycle * 0.75f)
                    val mouthWidth = w * 0.16f
                    val mouthHeight = (h * 0.075f) * openFactor

                    // Inner mouth shadow / cavity
                    drawOval(
                        color = Color(0xFF4A121A),
                        topLeft = Offset(mouthCenterX - mouthWidth / 2f, mouthCenterY - mouthHeight / 2f),
                        size = Size(mouthWidth, mouthHeight)
                    )

                    // Upper teeth line visible during talking
                    if (openFactor > 0.45f) {
                        drawRoundRect(
                            color = Color(0xFFFFFFFF),
                            topLeft = Offset(mouthCenterX - (mouthWidth * 0.38f), mouthCenterY - (mouthHeight * 0.35f)),
                            size = Size(mouthWidth * 0.76f, mouthHeight * 0.3f),
                            cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                        )
                    }

                    // Tongue highlight inside mouth
                    if (openFactor > 0.55f) {
                        drawOval(
                            color = Color(0xFFE26D7D),
                            topLeft = Offset(mouthCenterX - (mouthWidth * 0.28f), mouthCenterY + (mouthHeight * 0.05f)),
                            size = Size(mouthWidth * 0.56f, mouthHeight * 0.45f)
                        )
                    }

                    // Natural lip contours
                    // Upper lip curve
                    val upperLipPath = Path().apply {
                        moveTo(mouthCenterX - mouthWidth / 2f, mouthCenterY)
                        quadraticTo(
                            mouthCenterX,
                            mouthCenterY - (mouthHeight * 0.6f),
                            mouthCenterX + mouthWidth / 2f,
                            mouthCenterY
                        )
                    }
                    drawPath(
                        path = upperLipPath,
                        color = Color(0xFFB5495B),
                        style = Stroke(width = 2.dp.toPx())
                    )

                    // Lower lip curve
                    val lowerLipPath = Path().apply {
                        moveTo(mouthCenterX - mouthWidth / 2f, mouthCenterY)
                        quadraticTo(
                            mouthCenterX,
                            mouthCenterY + (mouthHeight * 0.6f),
                            mouthCenterX + mouthWidth / 2f,
                            mouthCenterY
                        )
                    }
                    drawPath(
                        path = lowerLipPath,
                        color = Color(0xFFD66073),
                        style = Stroke(width = 2.dp.toPx())
                    )
                }
            }

            // Holographic ambient scanline overlay
            Canvas(modifier = Modifier.size(size)) {
                // Subtle dark vignette at bottom
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.Transparent,
                            DarkNavyBackground.copy(alpha = 0.25f)
                        )
                    )
                )
            }
        }

        // Status pill badge at bottom of avatar
        val (badgeText, badgeColor, badgeIcon) = when {
            isSpeaking -> Triple("কথা বলছি…", PurpleGlow, Icons.Default.GraphicEq)
            speechState == SpeechState.LISTENING -> Triple("শুনছি… বলুন", CyanAccent, Icons.Default.Mic)
            speechState == SpeechState.THINKING -> Triple("ভাবছি…", PinkAccent, Icons.Default.AutoAwesome)
            else -> Triple("প্রস্তুত (Ready)", StatusReady, Icons.Default.AutoAwesome)
        }

        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .offset(y = 14.dp)
                .background(
                    color = DarkNavyCard.copy(alpha = 0.95f),
                    shape = RoundedCornerShape(16.dp)
                )
                .border(
                    width = 1.5.dp,
                    color = badgeColor.copy(alpha = 0.8f),
                    shape = RoundedCornerShape(16.dp)
                )
                .padding(horizontal = 14.dp, vertical = 6.dp)
                .testTag("avatar_status_badge")
        ) {
            androidx.compose.foundation.layout.Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = badgeIcon,
                    contentDescription = null,
                    tint = badgeColor,
                    modifier = Modifier.size(16.dp)
                )
                androidx.compose.foundation.layout.Spacer(modifier = Modifier.size(6.dp))
                Text(
                    text = badgeText,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
