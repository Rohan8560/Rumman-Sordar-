package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SpeechState
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.PinkAccent
import com.example.ui.theme.PurpleDeep
import com.example.ui.theme.PurpleGlow
import com.example.ui.theme.PurpleNeon
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun LargeMicButton(
    speechState: SpeechState,
    isSpeaking: Boolean,
    audioLevel: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    buttonSize: Dp = 84.dp
) {
    val isListening = speechState == SpeechState.LISTENING
    val isBusy = isListening || isSpeaking || speechState == SpeechState.THINKING

    val transition = rememberInfiniteTransition(label = "mic_ripple")

    val rippleScale by transition.animateFloat(
        initialValue = 1f,
        targetValue = 1.35f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "mic_ripple_scale"
    )

    val rippleAlpha by transition.animateFloat(
        initialValue = 0.6f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "mic_ripple_alpha"
    )

    val buttonGradient = when {
        isListening -> Brush.linearGradient(listOf(CyanNeon, CyanAccent, PurpleNeon))
        isSpeaking -> Brush.linearGradient(listOf(PurpleNeon, PinkAccent, PurpleDeep))
        speechState == SpeechState.THINKING -> Brush.linearGradient(listOf(PinkAccent, PurpleNeon))
        else -> Brush.linearGradient(listOf(PurpleNeon, PurplePrimary, PurpleDeep))
    }

    val glowColor = when {
        isListening -> CyanNeon
        isSpeaking -> PurpleNeon
        speechState == SpeechState.THINKING -> PinkAccent
        else -> PurplePrimary
    }

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(buttonSize + 40.dp)
        ) {
            // Animated ripple ring when active
            if (isBusy) {
                Box(
                    modifier = Modifier
                        .size(buttonSize)
                        .scale(rippleScale + (audioLevel * 0.2f))
                        .clip(CircleShape)
                        .background(glowColor.copy(alpha = rippleAlpha))
                )
                Box(
                    modifier = Modifier
                        .size(buttonSize)
                        .scale((rippleScale * 0.85f) + 0.15f)
                        .clip(CircleShape)
                        .background(PurpleGlow.copy(alpha = rippleAlpha * 0.7f))
                )
            }

            // Main Microphone Circle Button
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(buttonSize)
                    .shadow(
                        elevation = if (isBusy) 22.dp else 10.dp,
                        shape = CircleShape,
                        ambientColor = glowColor,
                        spotColor = glowColor
                    )
                    .clip(CircleShape)
                    .background(buttonGradient)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = ripple(bounded = true, color = Color.White),
                        onClick = onClick
                    )
                    .testTag("large_mic_button")
            ) {
                Icon(
                    imageVector = if (isBusy) Icons.Default.Stop else Icons.Default.Mic,
                    contentDescription = if (isBusy) "Stop speech" else "Start speech",
                    tint = Color.White,
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("large_mic_icon")
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Bengali status label below the button
        val statusLabel = when {
            isListening -> "শুনছি… ট্যাপ করে শেষ করুন"
            isSpeaking -> "রুমান কথা বলছে… ট্যাপ করে থামান"
            speechState == SpeechState.THINKING -> "উত্তর তৈরি হচ্ছে…"
            else -> "কথা বলতে ট্যাপ করুন"
        }

        Text(
            text = statusLabel,
            color = if (isBusy) CyanAccent else TextSecondary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.testTag("mic_status_label")
        )
    }
}
