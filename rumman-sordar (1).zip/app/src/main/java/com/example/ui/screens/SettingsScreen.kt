package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import android.content.Intent
import android.provider.Settings
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.social.MessengerHelper
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.DarkNavyBackground
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavyCardElevated
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.PinkAccent
import com.example.ui.theme.PurpleGlow
import com.example.ui.theme.PurpleNeon
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.StatusReady
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AssistantViewModel

@Composable
fun SettingsScreen(
    viewModel: AssistantViewModel,
    hasMicPermission: Boolean,
    onRequestPermission: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val voicePitch by viewModel.voicePitch.collectAsState()
    val voiceRate by viewModel.voiceRate.collectAsState()
    val isAutoSpeakEnabled by viewModel.isAutoSpeakEnabled.collectAsState()
    val selectedLanguage by viewModel.selectedLanguage.collectAsState()
    val isGeminiActive by viewModel.isGeminiActive.collectAsState()
    val activeEngineName by viewModel.activeEngineName.collectAsState()
    val activeVoiceName by viewModel.activeVoiceName.collectAsState()

    val isMessengerInstalled = MessengerHelper.isMessengerInstalled(context)

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkNavyBackground)
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp, vertical = 16.dp)
            .testTag("settings_screen")
    ) {
        Text(
            text = "সেটিংস ও কনফিগারেশন",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )
        Text(
            text = "ভয়েস, পারমিশন ও এআই ব্যাকএন্ড ম্যানেজ করুন",
            fontSize = 13.sp,
            color = PurpleGlow
        )

        Spacer(modifier = Modifier.height(18.dp))

        // SECTION 1: Voice & Speech Customization
        SettingsSectionHeader(icon = Icons.Default.RecordVoiceOver, title = "বাংলা ভয়েস ইঞ্জিন ও সেটিংস")

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NavyBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Active Engine & Voice Profile Banner
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkNavyCardElevated, RoundedCornerShape(12.dp))
                        .border(1.dp, PurpleNeon.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(StatusReady)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ভয়েস ইঞ্জিন: $activeEngineName",
                                color = TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "ভয়েস প্রোফাইল: $activeVoiceName",
                            color = PurpleGlow,
                            fontSize = 12.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Regional Bengali Dialect Selector
                Text(
                    text = "বাংলা ভাষার আঞ্চলিক রূপ (Dialect):",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val isBd = selectedLanguage == "bn-BD"
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(
                                if (isBd) PurplePrimary else DarkNavyCardElevated,
                                RoundedCornerShape(10.dp)
                            )
                            .border(
                                1.dp,
                                if (isBd) PurpleNeon else NavyBorder,
                                RoundedCornerShape(10.dp)
                            )
                            .clickable { viewModel.updateLanguage("bn-BD") }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "বাংলাদেশ (bn-BD)",
                            color = if (isBd) Color.White else TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = if (isBd) FontWeight.Bold else FontWeight.Normal
                        )
                    }

                    val isIndia = selectedLanguage == "bn-IN"
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(
                                if (isIndia) PurplePrimary else DarkNavyCardElevated,
                                RoundedCornerShape(10.dp)
                            )
                            .border(
                                1.dp,
                                if (isIndia) PurpleNeon else NavyBorder,
                                RoundedCornerShape(10.dp)
                            )
                            .clickable { viewModel.updateLanguage("bn-IN") }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "পশ্চিমবঙ্গ (bn-IN)",
                            color = if (isIndia) Color.White else TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = if (isIndia) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Female Voice Pitch Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "ভয়েস পিচ (Natural Female Tone)", color = TextPrimary, fontSize = 14.sp)
                    Text(text = String.format("%.2fx", voicePitch), color = PurpleNeon, fontSize = 14.sp)
                }
                Slider(
                    value = voicePitch,
                    onValueChange = { viewModel.updateVoicePitch(it) },
                    valueRange = 0.8f..1.6f,
                    colors = SliderDefaults.colors(
                        thumbColor = PurpleNeon,
                        activeTrackColor = PurplePrimary,
                        inactiveTrackColor = DarkNavyCardElevated
                    ),
                    modifier = Modifier.testTag("voice_pitch_slider")
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Speech Speed Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "কথার গতি (Conversational Speed)", color = TextPrimary, fontSize = 14.sp)
                    Text(text = String.format("%.2fx", voiceRate), color = CyanAccent, fontSize = 14.sp)
                }
                Slider(
                    value = voiceRate,
                    onValueChange = { viewModel.updateVoiceRate(it) },
                    valueRange = 0.7f..1.3f,
                    colors = SliderDefaults.colors(
                        thumbColor = CyanNeon,
                        activeTrackColor = CyanAccent,
                        inactiveTrackColor = DarkNavyCardElevated
                    ),
                    modifier = Modifier.testTag("voice_rate_slider")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Auto speak toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "উত্তরের অডিও স্বয়ংক্রিয় চালানো", color = TextPrimary, fontSize = 14.sp)
                        Text(
                            text = "উত্তর পাওয়ার সাথে সাথে মিষ্টি বাংলা কণ্ঠে শুনুন",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    Switch(
                        checked = isAutoSpeakEnabled,
                        onCheckedChange = { viewModel.toggleAutoSpeak(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = PurplePrimary
                        ),
                        modifier = Modifier.testTag("auto_speak_switch")
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Test voice button
                Button(
                    onClick = {
                        viewModel.speakText("নমস্কার! আমি রুমান সরদার, আপনার মিষ্টি বাংলা ভয়েস সহকারী। আমি আপনার যেকোনো প্রশ্নের উত্তর দিতে প্রস্তুত।")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("test_voice_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "কণ্ঠস্বর পরীক্ষা করুন (Test Voice)")
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Open Android system TTS settings button
                OutlinedButton(
                    onClick = {
                        try {
                            val intent = Intent("com.android.settings.TTS_SETTINGS").apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            try {
                                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(intent)
                            } catch (e2: Exception) {
                                // Ignore
                            }
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("system_tts_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = TextSecondary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ডিভাইস ভয়েস সেটিংস (Install Extra Voice Data)",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // SECTION 2: Android Permissions & Integrations
        SettingsSectionHeader(icon = Icons.Default.Tune, title = "অনুমতি ও ইন্টিগ্রেশন (Permissions)")

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NavyBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Microphone permission status
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = null,
                            tint = if (hasMicPermission) StatusReady else PinkAccent,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(text = "মাইক্রোফোন অনুমতি", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text(
                                text = if (hasMicPermission) "অনুমতি প্রদান করা হয়েছে (Granted)" else "অনুমতি প্রয়োজন (Needs Permission)",
                                color = if (hasMicPermission) StatusReady else PinkAccent,
                                fontSize = 12.sp
                            )
                        }
                    }

                    if (!hasMicPermission) {
                        OutlinedButton(
                            onClick = onRequestPermission,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(text = "অনুমোদন দিন", fontSize = 12.sp, color = PinkAccent)
                        }
                    } else {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = StatusReady)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Messenger Integration Status
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = null,
                            tint = CyanAccent,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(text = "ফেসবুক মেসেঞ্জার", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text(
                                text = if (isMessengerInstalled) "মেসেঞ্জার অ্যাপ ইন্সটল করা আছে" else "ডিফল্ট শেয়ার ও মেসেজ মোড সক্রিয়",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            viewModel.prepareMessengerMessage("শুভকামনা! আমি রুমান সরদার এআই থেকে এই বার্তাটি তৈরি করেছি।")
                        },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("test_messenger_button")
                    ) {
                        Text(text = "টেস্ট বার্তা", fontSize = 12.sp, color = CyanAccent)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkNavyCardElevated, RoundedCornerShape(10.dp))
                        .padding(10.dp)
                ) {
                    Text(
                        text = "নিরাপত্তা নীতি: কোনো বার্তা ব্যবহারকারীর স্পষ্ট সম্মতি (Confirmation Dialog) ছাড়া সরাসরি পাঠানো হয় না। প্রতিটি বার্তা ড্রাফট হিসেবে খোলে।",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // SECTION 3: Backend & API Configuration
        SettingsSectionHeader(icon = Icons.Default.Key, title = "এআই ব্যাকএন্ড কনফিগারেশন")

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NavyBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (isGeminiActive) StatusReady else CyanAccent)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isGeminiActive) "Gemini API সক্রিয় (Connected)" else "স্মার্ট অফলাইন বাংলা ইঞ্জিন সক্রিয়",
                        color = if (isGeminiActive) StatusReady else CyanAccent,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = if (isGeminiActive) {
                        "আপনার এআই ব্যাকএন্ড ক্লাউড জেনারেটিভ মডেলের সাথে সংযুক্ত রয়েছে। রুমান সরদার যেকোনো জটিল বাংলা প্রশ্নের বিস্তারিত উত্তর দিতে পারে।"
                    } else {
                        "বর্তমানে কোনো এক্সটার্নাল এপিআই কি ছাড়া অ্যাপটি অভ্যন্তরীণ বাংলা প্রাকৃতিক ভাষা প্রক্রিয়াকরণ ও ভয়েস মডেল দিয়ে সম্পূর্ণ কার্যকরভাবে চলছে।"
                    },
                    color = TextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkNavyCardElevated, RoundedCornerShape(12.dp))
                        .border(1.dp, NavyBorder, RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = PurpleGlow, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "কীভাবে Gemini API যুক্ত করবেন:", color = PurpleGlow, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "১. Google AI Studio এর Secrets প্যানেলে যান\n২. GEMINI_API_KEY সিক্রেট তৈরি করুন\n৩. অ্যাপটি কোনো কোড পরিবর্তন ছাড়াই স্বয়ংক্রিয়ভাবে ক্লাউড জেনারেটিভ মোড চালু করবে। কোডে কোনো এপিআই কি হার্ডকোড করা নেই।",
                            color = TextSecondary,
                            fontSize = 12.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // SECTION 4: About & Version
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NavyBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkNavyCardElevated),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(text = "Rumman Sordar AI", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 16.sp)
                Text(text = "Version 1.0.0 • Native Android Kotlin & Compose", color = TextSecondary, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "মিষ্টি বাংলা ভয়েস ও ফ্রেন্ডলি ৩ডি ফিমেল অবতার সহকারী",
                    color = PurpleGlow,
                    fontSize = 12.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun SettingsSectionHeader(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = PurpleNeon, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = title, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}
