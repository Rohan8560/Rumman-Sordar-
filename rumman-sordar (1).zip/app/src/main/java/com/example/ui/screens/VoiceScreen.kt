package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SpeechState
import com.example.ui.components.AudioVisualizer
import com.example.ui.components.AvatarView
import com.example.ui.components.LargeMicButton
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.DarkNavyBackground
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavyCardElevated
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.PinkAccent
import com.example.ui.theme.PurpleGlow
import com.example.ui.theme.PurpleNeon
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AssistantViewModel

@Composable
fun VoiceScreen(
    viewModel: AssistantViewModel,
    hasMicPermission: Boolean,
    onRequestPermission: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val speechState by viewModel.speechState.collectAsState()
    val isAvatarSpeaking by viewModel.isAvatarSpeaking.collectAsState()
    val audioLevel by viewModel.audioLevel.collectAsState()
    val transcript by viewModel.currentTranscript.collectAsState()
    val currentAiReply by viewModel.currentAiReply.collectAsState()
    val isGeminiActive by viewModel.isGeminiActive.collectAsState()
    val statusNotice by viewModel.statusNotice.collectAsState()

    val quickPrompts = listOf(
        "কেমন আছেন?",
        "একটি মজার কৌতুক বলুন",
        "মেসেঞ্জারে বার্তা পাঠাও",
        "একটি সুন্দর কবিতা শোনাও",
        "আজকের সময় ও তারিখ কত?",
        "তোমার পরিচয় দাও"
    )

    val scrollState = rememberScrollState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DarkNavyBackground)
            .testTag("voice_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top App Bar / Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Rumman Sordar",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "বাংলা ভয়েস এআই সহকারী",
                        fontSize = 12.sp,
                        color = PurpleGlow
                    )
                }

                // AI Engine indicator badge
                Box(
                    modifier = Modifier
                        .background(
                            color = if (isGeminiActive) PurplePrimary.copy(alpha = 0.25f) else DarkNavyCardElevated,
                            shape = RoundedCornerShape(12.dp)
                        )
                        .border(
                            width = 1.dp,
                            color = if (isGeminiActive) PurpleNeon else NavyBorder,
                            shape = RoundedCornerShape(12.dp)
                        )
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = if (isGeminiActive) PurpleGlow else CyanAccent,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isGeminiActive) "Gemini AI" else "Smart Voice AI",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (isGeminiActive) PurpleGlow else CyanAccent
                        )
                    }
                }
            }

            // Permission Warning Card if not granted
            if (!hasMicPermission) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .border(1.dp, PinkAccent.copy(alpha = 0.6f), RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = DarkNavyCardElevated),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = null,
                            tint = PinkAccent,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "মাইক্রোফোন অনুমতি প্রয়োজন",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "স্বাভাবিকভাবে কথা বলতে মাইক্রোফোনের অনুমতি দিন।",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                        Button(
                            onClick = onRequestPermission,
                            colors = ButtonDefaults.buttonColors(containerColor = PinkAccent),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(text = "অনুমতি দিন", fontSize = 12.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 3D Avatar Centerpiece with mouth animation
            AvatarView(
                speechState = speechState,
                isSpeaking = isAvatarSpeaking,
                audioLevel = audioLevel,
                size = 200.dp,
                modifier = Modifier.padding(vertical = 6.dp)
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Live user speech transcript bubble (appears when listening or speaking)
            AnimatedVisibility(
                visible = transcript.isNotBlank(),
                enter = fadeIn() + slideInVertically(),
                exit = fadeOut()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .background(
                            brush = Brush.horizontalGradient(
                                listOf(DarkNavyCardElevated, DarkNavyCard)
                            ),
                            shape = RoundedCornerShape(16.dp)
                        )
                        .border(1.dp, CyanNeon.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(CyanNeon)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = transcript,
                            color = CyanAccent,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // AI Response Card with Text & Quick Action Buttons
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .border(1.dp, NavyBorder, RoundedCornerShape(20.dp))
                    .testTag("ai_response_card"),
                colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "রুমানের উত্তর (Text Response)",
                            color = PurpleGlow,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )

                        Row {
                            // Replay audio button
                            IconButton(
                                onClick = { viewModel.speakText(currentAiReply) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                    contentDescription = "Replay speech",
                                    tint = PurpleNeon,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            // Share to Messenger button
                            IconButton(
                                onClick = { viewModel.prepareMessengerMessage(currentAiReply) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = "Send to Messenger",
                                    tint = CyanAccent,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            // Copy text button
                            IconButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Rumman AI", currentAiReply))
                                    Toast.makeText(context, "টেক্সট কপি করা হয়েছে", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "Copy text",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = currentAiReply,
                        color = TextPrimary,
                        fontSize = 15.sp,
                        lineHeight = 22.sp,
                        fontWeight = FontWeight.Normal
                    )

                    if (statusNotice != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = statusNotice ?: "",
                            color = PinkAccent,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            // Audio Visualizer Wave
            AudioVisualizer(
                isActive = speechState == SpeechState.LISTENING,
                audioLevel = audioLevel,
                isSpeaking = isAvatarSpeaking,
                modifier = Modifier.padding(vertical = 4.dp),
                height = 36.dp
            )

            // Quick Bengali Prompt Suggestion Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                quickPrompts.forEach { prompt ->
                    Box(
                        modifier = Modifier
                            .background(DarkNavyCardElevated, RoundedCornerShape(16.dp))
                            .border(1.dp, NavyBorder, RoundedCornerShape(16.dp))
                            .clickable {
                                viewModel.processUserMessage(prompt)
                            }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = prompt,
                            color = TextSecondary,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Large Center Microphone Button
            LargeMicButton(
                speechState = speechState,
                isSpeaking = isAvatarSpeaking,
                audioLevel = audioLevel,
                onClick = {
                    if (!hasMicPermission) {
                        onRequestPermission()
                    } else if (speechState == SpeechState.LISTENING) {
                        viewModel.stopListening()
                    } else if (isAvatarSpeaking) {
                        viewModel.stopSpeaking()
                    } else {
                        viewModel.startListening()
                    }
                },
                buttonSize = 82.dp
            )

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
