package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Navy & Midnight shades
val DarkNavyBackground = Color(0xFF090D1A)
val DarkNavySurface = Color(0xFF11172A)
val DarkNavyCard = Color(0xFF19223D)
val DarkNavyCardElevated = Color(0xFF222D4E)
val NavyBorder = Color(0xFF2D3B64)

// Vibrant Purple & Violet accents
val PurpleNeon = Color(0xFFA855F7)
val PurplePrimary = Color(0xFF8B5CF6)
val PurpleDeep = Color(0xFF6D28D9)
val PurpleGlow = Color(0xFFC084FC)

// Cyan & Pink energetic accents
val CyanNeon = Color(0xFF06B6D4)
val CyanAccent = Color(0xFF22D3EE)
val PinkAccent = Color(0xFFF43F5E)

// Text & Content colors
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)

// Status colors
val StatusListening = Color(0xFF06B6D4)
val StatusSpeaking = Color(0xFFA855F7)
val StatusReady = Color(0xFF10B981)
val StatusError = Color(0xFFEF4444)
