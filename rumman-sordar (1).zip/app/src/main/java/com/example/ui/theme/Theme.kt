package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val PremiumNavyPurpleColorScheme = darkColorScheme(
  primary = PurplePrimary,
  onPrimary = Color.White,
  primaryContainer = PurpleDeep,
  onPrimaryContainer = PurpleGlow,
  secondary = CyanNeon,
  onSecondary = Color.Black,
  secondaryContainer = NavyBorder,
  onSecondaryContainer = CyanAccent,
  tertiary = PinkAccent,
  onTertiary = Color.White,
  background = DarkNavyBackground,
  onBackground = TextPrimary,
  surface = DarkNavySurface,
  onSurface = TextPrimary,
  surfaceVariant = DarkNavyCard,
  onSurfaceVariant = TextSecondary,
  outline = NavyBorder,
  outlineVariant = DarkNavyCardElevated
)

@Composable
fun RummanSordarTheme(
  content: @Composable () -> Unit
) {
  MaterialTheme(
    colorScheme = PremiumNavyPurpleColorScheme,
    typography = Typography,
    content = content
  )
}

// Backward compatibility alias
@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit
) {
  RummanSordarTheme(content = content)
}
