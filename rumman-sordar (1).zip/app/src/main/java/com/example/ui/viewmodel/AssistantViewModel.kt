package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.AiAssistantService
import com.example.data.model.ChatMessage
import com.example.data.model.SpeechState
import com.example.data.social.MessengerHelper
import com.example.data.voice.VoiceManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AssistantViewModel(application: Application) : AndroidViewModel(application) {

    private val aiService = AiAssistantService()

    private val _speechState = MutableStateFlow(SpeechState.IDLE)
    val speechState: StateFlow<SpeechState> = _speechState.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                text = "নমস্কার ও আসসালামু আলাইকুম! আমি রুমান সরদার এআই। আপনার সাথে মিষ্টি বাংলায় কথা বলতে পেরে আমি আনন্দিত। কথা বলতে নিচের মাইক্রোফোন বাটনে চাপুন!",
                isUser = false
            )
        )
    )
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _currentTranscript = MutableStateFlow("")
    val currentTranscript: StateFlow<String> = _currentTranscript.asStateFlow()

    private val _currentAiReply = MutableStateFlow("হ্যালো! আমি আপনার বাংলা ভয়েস অ্যাসিস্ট্যান্ট। মাইক্রোফোনে ট্যাপ করে কথা বলুন।")
    val currentAiReply: StateFlow<String> = _currentAiReply.asStateFlow()

    private val _audioLevel = MutableStateFlow(0f)
    val audioLevel: StateFlow<Float> = _audioLevel.asStateFlow()

    private val _isAvatarSpeaking = MutableStateFlow(false)
    val isAvatarSpeaking: StateFlow<Boolean> = _isAvatarSpeaking.asStateFlow()

    private val _isMessengerDialogOpen = MutableStateFlow(false)
    val isMessengerDialogOpen: StateFlow<Boolean> = _isMessengerDialogOpen.asStateFlow()

    private val _pendingMessengerMessage = MutableStateFlow("")
    val pendingMessengerMessage: StateFlow<String> = _pendingMessengerMessage.asStateFlow()

    private val _voicePitch = MutableStateFlow(1.25f)
    val voicePitch: StateFlow<Float> = _voicePitch.asStateFlow()

    private val _voiceRate = MutableStateFlow(0.95f)
    val voiceRate: StateFlow<Float> = _voiceRate.asStateFlow()

    private val _isAutoSpeakEnabled = MutableStateFlow(true)
    val isAutoSpeakEnabled: StateFlow<Boolean> = _isAutoSpeakEnabled.asStateFlow()

    private val _selectedLanguage = MutableStateFlow("bn-BD")
    val selectedLanguage: StateFlow<String> = _selectedLanguage.asStateFlow()

    private val _isGeminiActive = MutableStateFlow(aiService.isGeminiConfigured())
    val isGeminiActive: StateFlow<Boolean> = _isGeminiActive.asStateFlow()

    private val _statusNotice = MutableStateFlow<String?>(null)
    val statusNotice: StateFlow<String?> = _statusNotice.asStateFlow()

    private val _activeEngineName = MutableStateFlow("Google Speech Services")
    val activeEngineName: StateFlow<String> = _activeEngineName.asStateFlow()

    private val _activeVoiceName = MutableStateFlow("Bengali Natural Female")
    val activeVoiceName: StateFlow<String> = _activeVoiceName.asStateFlow()

    private var voiceManager: VoiceManager? = null

    init {
        initVoiceManager()
    }

    private fun initVoiceManager() {
        voiceManager = VoiceManager(
            context = getApplication(),
            onTranscriptUpdate = { text, isFinal ->
                _currentTranscript.value = text
                if (isFinal && text.isNotBlank()) {
                    processUserMessage(text)
                }
            },
            onRmsChanged = { level ->
                _audioLevel.value = level
            },
            onSpeechStateChanged = { isSpeaking ->
                _isAvatarSpeaking.value = isSpeaking
                if (isSpeaking) {
                    _speechState.value = SpeechState.SPEAKING
                } else if (_speechState.value == SpeechState.SPEAKING) {
                    _speechState.value = SpeechState.IDLE
                }
            },
            onError = { errMsg ->
                _speechState.value = SpeechState.ERROR
                _statusNotice.value = errMsg
            }
        ).apply {
            currentPitch = _voicePitch.value
            currentRate = _voiceRate.value
            selectedLocaleTag = _selectedLanguage.value
        }
        voiceManager?.let {
            _activeEngineName.value = it.activeEngineName
            _activeVoiceName.value = it.activeVoiceName
        }
    }

    fun startListening() {
        _statusNotice.value = null
        _currentTranscript.value = ""
        _speechState.value = SpeechState.LISTENING
        voiceManager?.startListening()
    }

    fun stopListening() {
        voiceManager?.stopListening()
        if (_speechState.value == SpeechState.LISTENING) {
            _speechState.value = SpeechState.IDLE
        }
    }

    fun processUserMessage(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return

        stopListening()
        val userMsg = ChatMessage(text = trimmed, isUser = true)
        _messages.value = _messages.value + userMsg
        _speechState.value = SpeechState.THINKING

        viewModelScope.launch {
            try {
                val reply = aiService.getResponse(trimmed)
                val aiMsg = ChatMessage(text = reply, isUser = false)
                _messages.value = _messages.value + aiMsg
                _currentAiReply.value = reply

                // Check for Messenger intent
                val lower = trimmed.lowercase()
                if (lower.contains("মেসেঞ্জার") || lower.contains("messenger") || lower.contains("মেসেজ পাঠা") || lower.contains("বার্তা পাঠা")) {
                    prepareMessengerMessage(reply)
                }

                if (_isAutoSpeakEnabled.value) {
                    speakText(reply)
                } else {
                    _speechState.value = SpeechState.IDLE
                }
            } catch (e: Exception) {
                val errorReply = "দুঃখিত, উত্তর পেতে কিছুটা সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।"
                _messages.value = _messages.value + ChatMessage(text = errorReply, isUser = false)
                _currentAiReply.value = errorReply
                _speechState.value = SpeechState.ERROR
            }
        }
    }

    fun speakText(text: String) {
        _statusNotice.value = null
        voiceManager?.speak(text)
    }

    fun stopSpeaking() {
        voiceManager?.stopSpeaking()
        _isAvatarSpeaking.value = false
        _speechState.value = SpeechState.IDLE
    }

    fun prepareMessengerMessage(message: String) {
        _pendingMessengerMessage.value = message
        _isMessengerDialogOpen.value = true
    }

    fun confirmSendMessenger(context: Context) {
        val msg = _pendingMessengerMessage.value
        MessengerHelper.openMessengerWithMessage(context, msg)
        _isMessengerDialogOpen.value = false
    }

    fun dismissMessengerDialog() {
        _isMessengerDialogOpen.value = false
    }

    fun clearHistory() {
        _messages.value = listOf(
            ChatMessage(
                text = "চ্যাট হিস্ট্রি রিসেট করা হয়েছে। কথা বলতে নিচের মাইক্রোফোনে চাপুন!",
                isUser = false
            )
        )
        _currentAiReply.value = "হ্যালো! আমি আপনার বাংলা ভয়েস অ্যাসিস্ট্যান্ট।"
        _currentTranscript.value = ""
        stopSpeaking()
    }

    fun updateVoicePitch(pitch: Float) {
        _voicePitch.value = pitch
        voiceManager?.currentPitch = pitch
    }

    fun updateVoiceRate(rate: Float) {
        _voiceRate.value = rate
        voiceManager?.currentRate = rate
    }

    fun toggleAutoSpeak(enabled: Boolean) {
        _isAutoSpeakEnabled.value = enabled
        if (!enabled) {
            stopSpeaking()
        }
    }

    fun updateLanguage(lang: String) {
        _selectedLanguage.value = lang
        voiceManager?.selectedLocaleTag = lang
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager?.release()
    }
}
