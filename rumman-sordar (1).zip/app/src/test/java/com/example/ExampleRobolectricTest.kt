package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.ai.AiAssistantService
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Rumman Sordar", appName)
  }

  @Test
  fun `test smart bengali ai response`() = runBlocking {
    val service = AiAssistantService()
    val greetingReply = service.getResponse("হ্যালো কেমন আছো?")
    assertTrue(greetingReply.isNotEmpty())
  }
}
